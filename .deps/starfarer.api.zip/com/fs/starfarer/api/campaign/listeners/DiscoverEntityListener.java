package com.fs.starfarer.api.campaign.listeners;

import com.fs.starfarer.api.campaign.SectorEntityToken;

public interface DiscoverEntityListener {
	void reportEntityDiscovered(SectorEntityToken entity);
}
