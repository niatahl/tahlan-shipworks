package com.fs.starfarer.api.campaign;

public interface OrbitalStationAPI extends SectorEntityToken {

}
