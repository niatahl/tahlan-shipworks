package com.fs.starfarer.api.impl.campaign.econ;


public class WorldBarrenMarginal extends WorldFarming {

	public WorldBarrenMarginal() {
		super(ConditionData.WORLD_BARREN_MARGINAL_FARMING_MULT, ConditionData.WORLD_BARREN_MARGINAL_MACHINERY_MULT);
	}

}
