package com.fs.starfarer.api.impl.campaign.econ;


public class RuralPolity extends BaseMarketConditionPlugin {

	public void apply(String id) {
	}

	public void unapply(String id) {
	}

}
