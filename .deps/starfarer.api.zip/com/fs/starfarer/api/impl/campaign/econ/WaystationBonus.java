package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.campaign.econ.MarketAPI;

public class WaystationBonus {
	public float impact;
	public MarketAPI market;
}
