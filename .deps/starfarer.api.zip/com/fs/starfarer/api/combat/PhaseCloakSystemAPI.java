package com.fs.starfarer.api.combat;

public interface PhaseCloakSystemAPI {
	float getMinCoilJitterLevel();
	void setMinCoilJitterLevel(float minJitterLevel);

}
